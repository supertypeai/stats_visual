# stats_viz package

This package can visualize various statistical distributions along with their probability mass or density function and cumulative probability.